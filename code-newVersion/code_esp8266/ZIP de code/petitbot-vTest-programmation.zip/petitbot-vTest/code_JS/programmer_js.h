#ifndef PROGRAMMER_JS_H
#define PROGRAMMER_JS_H

const char PROGRAMMER_JS[] PROGMEM = R"rawliteral(
let program = [];
let isRunning = false;

// Permet le drop
window.allowDrop = function(ev) {
  ev.preventDefault();
};

// Glisser un bloc
window.drag = function(ev) {
  ev.dataTransfer.setData("text", ev.target.id);
  ev.dataTransfer.setData("type", ev.target.querySelector('span') ? ev.target.querySelector('span').textContent : 'WAIT');
  if (ev.target.id === 'wait-block') {
    const time = document.getElementById('wait-time').value;
    ev.dataTransfer.setData("time", time);
  }
};

// Déposer un bloc
window.drop = function(ev) {
  ev.preventDefault();
  const blockId = ev.dataTransfer.getData("text");
  const blockType = ev.dataTransfer.getData("type");
  const time = ev.dataTransfer.getData("time");

  addBlockToProgram(blockId, blockType, time);
};

// Fonction pour ajouter un bloc au programme
function addBlockToProgram(blockId, blockType, time) {
  const blockElement = document.createElement("div");
  blockElement.className = "dropped-block";

  let blockContent = "";
  if (blockType === 'WAIT') {
    blockContent = `<strong>Attendre</strong> <span>${time} seconde(s)</span>`;
  } else {
    const blockName = document.getElementById(blockId).querySelector('strong').textContent;
    blockContent = `<strong>${blockName}</strong> <span>${blockType}</span>`;
  }

  blockElement.innerHTML = blockContent + `
    <button class="remove-btn" onclick="removeBlock(this)">×</button>
  `;

  document.getElementById("program-area").appendChild(blockElement);

  // Ajoute au programme
  if (blockType === 'WAIT') {
    program.push({ type: blockType, time: parseInt(time) });
  } else {
    program.push({ type: blockType });
  }
}

// Placer un bloc avec le bouton "Placer"
window.placeBlock = function(blockId) {
  const block = document.getElementById(blockId);
  const blockType = block.querySelector('span').textContent;
  addBlockToProgram(blockId, blockType, 1);
};

// Placer un bloc "Attendre" avec le bouton "Placer"
window.placeWaitBlock = function() {
  const time = document.getElementById('wait-time').value;
  addBlockToProgram('wait-block', 'WAIT', time);
};

// Supprimer un bloc
window.removeBlock = function(button) {
  const blockElement = button.parentElement;
  const index = Array.from(blockElement.parentElement.children).indexOf(blockElement);

  blockElement.remove();
  program.splice(index, 1);
};

// Effacer le programme
window.clearProgram = function() {
  fetch('/stopMotors');
  document.getElementById("program-area").innerHTML = "";
  program = [];
  isRunning = false;
  document.getElementById("run-btn").disabled = false;
  document.getElementById("stop-btn").disabled = true;
};

// Exécuter le programme
window.runProgram = function() {
  if (program.length === 0) {
    alert("Aucun bloc dans le programme !");
    return;
  }

  // Désactive les boutons pendant l'exécution
  document.getElementById("run-btn").disabled = true;
  document.getElementById("stop-btn").disabled = false;
  document.getElementById("clear-btn").disabled = true;
  document.getElementById("save-btn").disabled = true;
  document.getElementById("load-btn").disabled = true;
  isRunning = true;

  executeStep(0); // Commence l'exécution
};

// Arrêter le programme
window.stopProgram = function() {
  fetch('/stopMotors');
  isRunning = false;

  // Réactive les boutons
  document.getElementById("run-btn").disabled = false;
  document.getElementById("stop-btn").disabled = false;
  document.getElementById("clear-btn").disabled = false;
  document.getElementById("save-btn").disabled = false;
  document.getElementById("load-btn").disabled = false;
};

// Exécute une étape du programme
function executeStep(index) {
  if (index >= program.length || !isRunning) {
    // Fin du programme ou arrêt manuel
    document.getElementById("run-btn").disabled = false;
    document.getElementById("stop-btn").disabled = false;
    document.getElementById("clear-btn").disabled = false;
    document.getElementById("save-btn").disabled = false;
    document.getElementById("load-btn").disabled = false;
    isRunning = false;
    return;
  }

  const step = program[index];

  if (step.type === 'WAIT') {
    // Attendre X secondes
    setTimeout(() => {
      if (isRunning) executeStep(index + 1);
    }, step.time * 1000);
  } else if (step.type === 'STOP') {
    fetch('/stopMotors')
      .then(() => {
        if (isRunning) setTimeout(() => executeStep(index + 1), 500);
      })
      .catch(error => {
        console.error("Erreur:", error);
        document.getElementById("run-btn").disabled = false;
        document.getElementById("stop-btn").disabled = true;
        document.getElementById("clear-btn").disabled = false;
        document.getElementById("save-btn").disabled = false;
        document.getElementById("load-btn").disabled = false;
        isRunning = false;
      });
  } else {
    // Envoyer la commande au robot
    fetch(`/UseTelecommande?val=${step.type}`)
      .then(() => {
        if (isRunning) setTimeout(() => executeStep(index + 1), 500);
      })
      .catch(error => {
        console.error("Erreur:", error);
        document.getElementById("run-btn").disabled = false;
        document.getElementById("stop-btn").disabled = true;
        document.getElementById("clear-btn").disabled = false;
        document.getElementById("save-btn").disabled = false;
        document.getElementById("load-btn").disabled = false;
        isRunning = false;
      });
  }
};

// Sauvegarder le programme (dans le sessionStorage)
window.saveProgram = function() {
  sessionStorage.setItem("petitbotProgram", JSON.stringify(program));
  alert("Programme sauvegardé !");
};

// Charger un programme
window.loadProgram = function() {
  const savedProgram = sessionStorage.getItem("petitbotProgram");
  if (savedProgram) {
    program = JSON.parse(savedProgram);
    renderProgram();
    alert("Programme chargé !");
  } else {
    alert("Aucun programme sauvegardé.");
  }
};

// Affiche le programme chargé
window.renderProgram = function() {
  const programArea = document.getElementById("program-area");
  programArea.innerHTML = "";

  program.forEach((step, index) => {
    const blockElement = document.createElement("div");
    blockElement.className = "dropped-block";

    let blockContent = "";
    if (step.type === 'WAIT') {
      blockContent = `<strong>Attendre</strong> <span>${step.time} seconde(s)</span>`;
    } else {
      let blockName = "";
      switch (step.type) {
        case "FORWARD": blockName = "Avancer"; break;
        case "REVERSE": blockName = "Reculer"; break;
        case "LEFT": blockName = "Gauche"; break;
        case "RIGHT": blockName = "Droite"; break;
        case "STOP": blockName = "Stop"; break;
      }
      blockContent = `<strong>${blockName}</strong> <span>${step.type}</span>`;
    }

    blockElement.innerHTML = blockContent + `
      <button class="remove-btn" onclick="removeBlock(this)">×</button>
    `;

    programArea.appendChild(blockElement);
  });
};

// Gestion du menu navbar
document.querySelector('.navbar-toggle')?.addEventListener('click', function() {
  document.getElementById('myNavbar')?.classList.toggle('open');
});
)rawliteral";
#endif
