#ifndef CONFIG_JS_H
#define CONFIG_JS_H



const char CONFIG_JS[] PROGMEM = R"rawliteral(

  // changement d'état de la navbar sur mobile
  document.querySelector('.navbar-toggle').onclick = function() {
    document.getElementById('myNavbar').classList.toggle('open');
  };

// Fonction unique pour le chargement de la page
window.onload = function() {

  // Récupérer l'état depuis l'ESP8266
  fetch('/get-state')
    .then(response => response.text())
    .then(data => {
      // Séparer les valeurs par la virgule
      const [led, motorBF, motorLR] = data.split(',').map(Number);

      // Stocker dans sessionStorage
      sessionStorage.setItem('ledState', led);
      sessionStorage.setItem('motorBF', motorBF);
      sessionStorage.setItem('motorLR', motorLR);

      // Restaurer les états sauvegardés
      const ledState = sessionStorage.getItem('ledState');
      if (ledState) {
        const onBtn = document.getElementById('btnLed-on');
        const offBtn = document.getElementById('btnLed-off');
        onBtn.classList.remove('button-checked');
        offBtn.classList.remove('button-checked');
        if (ledState == 0) onBtn.classList.add('button-checked');
        else offBtn.classList.add('button-checked');
      }

      // Restaurer l'état des moteurs avant/arrière
      const motorStateFrontBack = sessionStorage.getItem('motorBF');
      if (motorStateFrontBack) {
        const yesBtn = document.getElementById('btnMotor-invert-yes');
        const noBtn = document.getElementById('btnMotor-invert-no');
        yesBtn.classList.remove('button-checked');
        noBtn.classList.remove('button-checked');
        if (motorStateFrontBack == 1) yesBtn.classList.add('button-checked');
        else noBtn.classList.add('button-checked');
      }

      // Restaurer l'état des moteurs gauche/droite
      const motorStateLeftRight = sessionStorage.getItem('motorLR');
      if (motorStateLeftRight) {
        const yesBtn = document.getElementById('btnMotor-invert-left-yes');
        const noBtn = document.getElementById('btnMotor-invert-left-no');
        yesBtn.classList.remove('button-checked');
        noBtn.classList.remove('button-checked');
        if (motorStateLeftRight == 1) yesBtn.classList.add('button-checked');
        else noBtn.classList.add('button-checked');
      }
    })
    .catch(error => console.error("Erreur :", error));
};

// Fonction générique pour mettre à jour un paramètre
function updateState({ param, value }) {
  const query = `/update-state?param=${encodeURIComponent(param)}&value=${encodeURIComponent(value)}`;

  fetch(query, { method: 'GET' })
    .then(response => response.text())
    .then(result => {
      // Met à jour le sessionStorage
      sessionStorage.setItem(param, value);
      // Met à jour l'UI
      updateUI(param, value);
    })
    .catch(error => console.error("Erreur :", error));
}

// Fonction pour mettre à jour l'UI en fonction du paramètre modifié
function updateUI(param, value) {
  if (param === 'ledState') {
    const onBtn = document.getElementById('btnLed-on');
    const offBtn = document.getElementById('btnLed-off');
    onBtn.classList.remove('button-checked');
    offBtn.classList.remove('button-checked');
    if (value == 0) onBtn.classList.add('button-checked');
    else offBtn.classList.add('button-checked');
  }
  else if (param === 'motorBF') {
    const yesBtn = document.getElementById('btnMotor-invert-yes');
    const noBtn = document.getElementById('btnMotor-invert-no');
    yesBtn.classList.remove('button-checked');
    noBtn.classList.remove('button-checked');
    if (value == 1) yesBtn.classList.add('button-checked');
    else noBtn.classList.add('button-checked');
  }
  else if (param === 'motorLR') {
    const yesBtn = document.getElementById('btnMotor-invert-left-yes');
    const noBtn = document.getElementById('btnMotor-invert-left-no');
    yesBtn.classList.remove('button-checked');
    noBtn.classList.remove('button-checked');
    if (value == 1) yesBtn.classList.add('button-checked');
    else noBtn.classList.add('button-checked');
  }
}

// Fonctions pour les boutons (utilisent updateState)
function controlLed(state) {
  let boolState ;
  if (state == 'ON'){boolState = 0;updateState({ param: 'ledState', value: boolState });}else if (state == 'OFF'){boolState = 1;updateState({ param: 'ledState', value: boolState });}else{updateState({ param: 'notgood', value: 1 });}
}

function motorInvertedFrontBack(state) {
    let boolState ;
    if (state === 'YES'){boolState = 1;updateState({ param: 'motorBF', value: boolState });}else if (state === 'NO'){boolState = 0;updateState({ param: 'motorBF', value: boolState });}else{updateState({ param: 'notgood', value: 2 });}
}

function motorInvertedLeftRight(state) {
  let boolState ;
    if (state == 'YES'){boolState = 1;updateState({ param: 'motorLR', value: boolState });}else if (state == 'NO'){boolState = 0;updateState({ param: 'motorLR', value: boolState });}else{updateState({ param: 'notgood', value: 3 });}
}

  // Mettre à jour le SSID
  function updateSSID() {
    const newSSID = document.getElementById("ssidInput").value;
    const statusElement = document.getElementById("status");

    if (!newSSID) {
      statusElement.textContent = "Veuillez saisir un SSID!";
      return;
    }

    fetch('/update?ssid=' + encodeURIComponent(newSSID))
      .then(response => {
        if (response.ok) {
          statusElement.textContent = "SSID mis à jour ! Redémarrage du Wi-Fi...";
          setTimeout(() => window.location.reload(), 2500);
        } else {
          statusElement.textContent = "Échec de la mise à jour du SSID.";
        }
      })
      .catch(error => {
        statusElement.textContent = "Erreur : " + error.message;
      });
  }

  // Réinitialiser la configuration
  function resetConfig() {
    fetch('/update?reset=all');
  }


)rawliteral";
#endif