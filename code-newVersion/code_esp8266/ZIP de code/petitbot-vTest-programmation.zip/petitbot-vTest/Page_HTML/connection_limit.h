#ifndef CONNECTION_LIMIT_H
#define CONNECTION_LIMIT_H

const char CONNECTION_LIMIT_PAGE[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Connexion Refusée</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body {
      padding: 20px;
      font-family: Arial, sans-serif;
      text-align: center;
    }
    .error-message {
      background: #ff6b6b;
      padding: 15px;
      border-radius: 5px;
      margin: 20px auto;
      max-width: 400px;
    }
    .restart-button {
      background: #4CAF50;
      color: white;
      padding: 10px 20px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 16px;
      margin: 20px auto;
      display: block;
      max-width: 200px;
    }
    .restart-button:hover {
      background: #45a049;
    }
  </style>
</head>
<body>
  <h1>Connexion Refusée</h1>
  <div class="error-message">
    <p>Un appareil est déjà connecté au PetitBot.</p>
    <p>Veuillez déconnecter cet appareil avant de vous connecter.</p>
  </div>

  <button class="restart-button" onclick="restartWiFi()">Redémarrer le réseau</button>

  <script>
    function restartWiFi() {
      fetch('/restart-wifi')
        .then(response => response.text())
        .then(data => {
          alert("Le réseau va redémarrer. Veuillez vous reconnecter.");
          window.location.href = "/loading"; // Redirige vers une page de chargement
        })
        .catch(error => {
          alert("Erreur lors du redémarrage du réseau.");
        });
    }
  </script>
</body>
</html>
)rawliteral";

#endif