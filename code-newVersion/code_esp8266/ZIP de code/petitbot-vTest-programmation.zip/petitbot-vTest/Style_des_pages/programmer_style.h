#ifndef PROGRAMMER_CSS_H
#define PROGRAMMER_CSS_H

const char PROGRAMMER_CSS[] PROGMEM = R"rawliteral(
.container {
  display: flex;
  flex-direction: column;
  gap: 20px;
  padding: 10px;
}

.blocks-panel, .program-panel {
  background: white;
  border-radius: 10px;
  padding: 15px;
  box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}

.blocks-panel {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.block-container {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 10px;
}

.block {
  background: #00adb5;
  color: white;
  padding: 10px;
  border-radius: 5px;
  cursor: grab;
  display: flex;
  justify-content: space-between;
  align-items: center;
  user-select: none;
  flex-grow: 1;
}

.place-btn {
  background: #4CAF50;
  color: white;
  border: none;
  border-radius: 5px;
  padding: 10px;
  cursor: pointer;
  white-space: nowrap;
}

.block:hover {
  background: #008aa0;
}

#program-area {
  min-height: 300px;
  background: #f9f9f9;
  border: 2px dashed #ccc;
  border-radius: 5px;
  padding: 10px;
  margin-bottom: 15px;
}

.controls {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  justify-content: center;
}

.controls .main-buttons {
  display: flex;
  gap: 10px;
  width: 100%;
  justify-content: center;
  margin-bottom: 10px;
}

#run-btn, #stop-btn {
  padding: 12px 24px;
  border: none;
  border-radius: 5px;
  color: white;
  cursor: pointer;
  font-size: 18px;
  font-weight: bold;
}

#run-btn {
  background: #4CAF50;
}

#stop-btn {
  background: #ff1100;
}

#run-btn:disabled, #stop-btn:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.hide {
display : none;
}

.controls .secondary-buttons {
  display: flex;
  gap: 10px;
  width: 100%;
  justify-content: center;
}

.controls button:not(#run-btn):not(#stop-btn) {
  padding: 8px 15px;
  border: none;
  border-radius: 5px;
  background: #00adb5;
  color: white;
  cursor: pointer;
}

.controls button:not(#run-btn):not(#stop-btn):hover {
  background: #007c80;
}

.dropped-block {
  background: #007c80;
  margin-bottom: 10px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px;
  border-radius: 5px;
  color: white;
}

.dropped-block .remove-btn {
  background: #ff6b6b;
  color: white;
  border: none;
  border-radius: 3px;
  padding: 2px 5px;
  cursor: pointer;
}

.program-title {
  color: black 
}
)rawliteral";
#endif