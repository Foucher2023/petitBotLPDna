#ifndef CONNECTION_LIMIT_JS_H
#define CONNECTION_LIMIT_JS_H



const char CONNECT_LIMIT_JS[] PROGMEM = R"rawliteral(
    function restartWiFi() {
      fetch('/restart-wifi')
        .then(response => response.text())
        .then(data => {
          alert("Le réseau va redémarrer. Veuillez vous reconnecter.");
          window.location.href = "/loading"; // Redirige vers une page de chargement
        })
        .catch(error => {
          alert("Erreur lors du redémarrage du réseau.");
        });
    }

)rawliteral";
#endif